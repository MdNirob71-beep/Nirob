<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- css link here -->
     <link rel="stylesheet" href="css/style.css">
    <!-- css link here -->
     <!-- fontawosome link here -->
     <script src="https://kit.fontawesome.com/11254cc4a5.js" crossorigin="anonymous"></script>
     <!-- fontawosome link here -->
    <title>হোম-ফিউচার কোচিং সেন্টার</title>
</head>
<body>
<div class="container">
    <!-- header section start -->
    <?php require 'header.php';?>
    <!-- header section end -->
     <!-- content section start -->
    <div class="content-section">

    </div>
    <!-- content section end -->
     <!-- footer section start -->
    <div class="footer-section">

    </div>
    <!-- footer section end -->
</div>
</body>
</html>