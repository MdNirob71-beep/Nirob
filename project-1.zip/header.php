<div class="header-section">
        <div class="contact-social-section">
            <div class="contact-part">
                <ul>
                    <li><a href="tel:8801928248173"><i class="fa fa-phone"></i>01928248173</a></li>
                    
                    <li><a href="mailto:fctisoftware@gmail.com"><i class="fa fa-envelope"></i>fctisoftware@gmail.com</a></li>
                </ul>
            </div>
            <div class="social-part">
                <ul>
                    <li><a href=""><i class="fa fa-facebook"></i></a></li>
                    <li><a href=""><i class="fa fa-youtube"></i></a></li>
                    <li><a href=""><i class="fa fa-instagram"></i></a></li>
                    <li><a href=""><i class="fa fa-linkedin"></i></a></li>
                    <li><a href=""><i class="fa fa-twitter"></i></a></li> 
                </ul>
            </div>
            <div class="langauge">
                <ul>
                    <li><a href="">BN</a></li>
                    <li><a href="">EN</a></li>
                </ul>
            </div>
        </div>
        <div class="menu-section">
            
        </div>
    </div>